#!/usr/bin/env bash
# ================= ChatGosipt — Instalador Linux =================
cd "$(dirname "$0")/.." || exit 1
DIR="$(pwd)/app"
echo "🎙️  Instalando ChatGosipt em: $DIR"
echo

if ! command -v python3 >/dev/null 2>&1; then
  echo "❌ Python 3 não encontrado. Instale com: sudo apt install python3 python3-venv python3-pip"
  exit 1
fi

# ffmpeg ajuda em alguns formatos
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "ℹ️  Dica: instale o ffmpeg para máxima compatibilidade: sudo apt install ffmpeg"
fi

cd "$DIR" || exit 1
echo "→ Criando ambiente..."
python3 -m venv .venv
./.venv/bin/python -m pip install --upgrade pip -q
echo "→ Instalando dependências (pode levar alguns minutos)..."
./.venv/bin/pip install -r requirements.txt -q
./.venv/bin/pip install "huggingface_hub==0.25.2" -q

echo
echo "✅ Instalado! Para abrir o ChatGosipt:"
echo "   cd \"$DIR\" && ./.venv/bin/python app.py"
echo
echo "💡 Resumos com IA local (opcional): instale o Ollama (https://ollama.com) e rode: ollama pull llama3.2:3b"
