#!/bin/bash
# ================= ChatGosipt — Instalador macOS =================
cd "$(dirname "$0")/.." || exit 1
DIR="$(pwd)/app"
echo "🎙️  Instalando ChatGosipt em: $DIR"
echo

if ! command -v python3 >/dev/null 2>&1; then
  echo "❌ Python 3 não encontrado. Instale em https://www.python.org/downloads/ e rode de novo."
  read -p "Enter para sair..."; exit 1
fi

cd "$DIR" || exit 1
echo "→ Criando ambiente..."
python3 -m venv .venv
./.venv/bin/python -m pip install --upgrade pip -q
echo "→ Instalando dependências (pode levar alguns minutos)..."
./.venv/bin/pip install -r requirements.txt -q
./.venv/bin/pip install "huggingface_hub==0.25.2" -q

echo
echo "✅ Instalado! Para abrir o ChatGosipt:"
echo "   cd \"$DIR\" && ./.venv/bin/python app.py"
echo
echo "💡 Para resumos com IA local (opcional): instale o Ollama em https://ollama.com"
echo "   e rode: ollama pull llama3.2:3b"
read -p "Enter para fechar..."
