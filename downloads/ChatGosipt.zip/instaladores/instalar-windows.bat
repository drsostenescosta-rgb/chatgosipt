@echo off
REM ================= ChatGosipt - Instalador Windows =================
cd /d "%~dp0.."
set DIR=%cd%\app
echo Instalando ChatGosipt em: %DIR%
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Python nao encontrado. Instale em https://www.python.org/downloads/
  echo Marque "Add Python to PATH" durante a instalacao.
  pause
  exit /b 1
)

cd /d "%DIR%"
echo -^> Criando ambiente...
python -m venv .venv
call .venv\Scripts\python.exe -m pip install --upgrade pip -q
echo -^> Instalando dependencias (pode levar alguns minutos)...
call .venv\Scripts\pip.exe install -r requirements.txt -q
call .venv\Scripts\pip.exe install "huggingface_hub==0.25.2" -q

echo.
echo [OK] Instalado! Para abrir o ChatGosipt:
echo    cd "%DIR%" ^&^& .venv\Scripts\python.exe app.py
echo.
echo Dica: para resumos com IA local, instale o Ollama em https://ollama.com
echo e rode: ollama pull llama3.2:3b
pause
