const btnStart = document.getElementById("btnStart");
const btnStop = document.getElementById("btnStop");
const dot = document.getElementById("dot");
const statusText = document.getElementById("statusText");
const resultBox = document.getElementById("result");

function setStatus(text, mode) {
  statusText.textContent = text;
  dot.className = "dot" + (mode ? " " + mode : "");
}

// Restaura estado (se já estiver gravando)
chrome.storage.local.get(["recording"], (s) => {
  if (s.recording) showRecording();
});

function showRecording() {
  btnStart.style.display = "none";
  btnStop.style.display = "block";
  setStatus("Gravando a reunião…", "rec");
  resultBox.style.display = "none";
}
function showIdle() {
  btnStart.style.display = "block";
  btnStop.style.display = "none";
}

btnStart.addEventListener("click", async () => {
  const opts = {
    idioma: document.getElementById("idioma").value,
    modelo: document.getElementById("modelo").value,
    resumir: document.getElementById("resumir").checked ? "1" : "0",
  };
  setStatus("Iniciando captura da aba…");
  const resp = await chrome.runtime.sendMessage({ type: "start", options: opts });
  if (resp && resp.ok) {
    chrome.storage.local.set({ recording: true });
    showRecording();
  } else {
    setStatus("Erro: " + (resp && resp.error ? resp.error : "não foi possível capturar a aba"));
  }
});

btnStop.addEventListener("click", async () => {
  setStatus("Transcrevendo… (pode levar alguns segundos)");
  btnStop.disabled = true;
  chrome.storage.local.set({ recording: false });
  const resp = await chrome.runtime.sendMessage({ type: "stop" });
  btnStop.disabled = false;
  showIdle();
  if (resp && resp.ok) {
    setStatus("Pronto!", "ok");
    renderResult(resp.data);
  } else {
    setStatus("Erro: " + (resp && resp.error ? resp.error : "falha ao transcrever"));
  }
});

function renderResult(data) {
  resultBox.style.display = "block";
  let html = "";
  if (data.resumo) {
    html += `<div class="sec"><h3>Resumo</h3>${escapeHtml(data.resumo)}</div>`;
  }
  html += `<div class="sec"><h3>Transcrição</h3>${escapeHtml(data.texto || "(vazio)")}</div>`;
  resultBox.innerHTML = html;
}

function escapeHtml(s) {
  const d = document.createElement("div");
  d.textContent = s;
  return d.innerHTML;
}
