// Offscreen document — captura o áudio da aba e envia para o ChatGosipt (API local)

const API = "http://127.0.0.1:7861/transcrever";

let recorder = null;
let chunks = [];
let audioCtx = null;
let opts = {};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target !== "offscreen") return false;

  if (msg.type === "start") {
    startRec(msg.streamId, msg.options)
      .then(() => sendResponse({ ok: true }))
      .catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }

  if (msg.type === "stop") {
    stopRec()
      .then((data) => sendResponse(data))
      .catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }

  return false;
});

async function startRec(streamId, options) {
  opts = options || {};
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: {
      mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: streamId },
    },
    video: false,
  });

  // Reproduz o áudio de volta para o usuário continuar ouvindo a reunião
  // (a captura da aba, sozinha, deixaria a aba muda).
  audioCtx = new AudioContext();
  const src = audioCtx.createMediaStreamSource(stream);
  src.connect(audioCtx.destination);

  chunks = [];
  const mime = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
    ? "audio/webm;codecs=opus"
    : "audio/webm";
  recorder = new MediaRecorder(stream, { mimeType: mime });
  recorder.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
  recorder.start(1000); // coleta a cada 1s
}

async function stopRec() {
  if (!recorder) throw new Error("nada gravando");

  const blob = await new Promise((resolve) => {
    recorder.onstop = () => resolve(new Blob(chunks, { type: "audio/webm" }));
    recorder.stop();
  });

  try { recorder.stream.getTracks().forEach((t) => t.stop()); } catch (e) {}
  try { if (audioCtx) await audioCtx.close(); } catch (e) {}
  recorder = null;

  const fd = new FormData();
  fd.append("audio", blob, "reuniao.webm");
  fd.append("modelo", opts.modelo || "small");
  fd.append("idioma", opts.idioma || "");
  fd.append("resumir", opts.resumir || "0");

  let resp;
  try {
    resp = await fetch(API, { method: "POST", body: fd });
  } catch (e) {
    throw new Error("não consegui falar com o ChatGosipt. O app está aberto no Mac?");
  }
  if (!resp.ok) throw new Error("ChatGosipt respondeu " + resp.status);
  const data = await resp.json();
  return { ok: true, data };
}
