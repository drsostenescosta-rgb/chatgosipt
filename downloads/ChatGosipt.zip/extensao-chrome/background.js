// Service worker — orquestra a captura da aba e o documento offscreen

let creating = null;

async function hasOffscreen() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
  });
  return contexts.length > 0;
}

async function ensureOffscreen() {
  if (await hasOffscreen()) return;
  if (creating) { await creating; return; }
  creating = chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["USER_MEDIA"],
    justification: "Gravar o áudio da aba da reunião para transcrever localmente.",
  });
  await creating;
  creating = null;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target === "offscreen") return false; // mensagem para o offscreen, não para cá

  if (msg.type === "start") {
    (async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) throw new Error("nenhuma aba ativa");
        const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
        await ensureOffscreen();
        const ack = await chrome.runtime.sendMessage({
          target: "offscreen", type: "start", streamId, options: msg.options,
        });
        if (!ack || !ack.ok) throw new Error(ack && ack.error ? ack.error : "falha ao iniciar gravação");
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: String(e.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "stop") {
    (async () => {
      try {
        const data = await chrome.runtime.sendMessage({ target: "offscreen", type: "stop" });
        sendResponse(data);
      } catch (e) {
        sendResponse({ ok: false, error: String(e.message || e) });
      }
    })();
    return true;
  }

  return false;
});
