# -*- coding: utf-8 -*-
"""
TRANSCRITOR PRO — Transcrição local com Whisper + Resumos com Ollama
=====================================================================
Funciona 100% offline (após baixar o modelo uma vez).

Recursos:
- Áudios do WhatsApp (.opus, .ogg), qualquer áudio/vídeo (mp3, mp4, m4a, wav...)
- Links de sites/vídeos (YouTube, Instagram, TikTok etc. — requer internet)
- Gravação de reuniões pelo microfone
- Resumo automático com Ollama (llama3, mistral etc. — local e offline)
- Exporta .txt e .srt (legendas) + botão de copiar

Como rodar:
    pip install -r requirements.txt
    python app.py
Abre em http://127.0.0.1:7860
"""

import os
import tempfile
import datetime

import gradio as gr

# ----------------------------------------------------------------------
# COMPAT: corrige bug do gradio_client (TypeError: 'bool' is not iterable)
# que quebra a checagem de API no startup e derruba o app com erro de
# "localhost não acessível". Guarda esquemas booleanos (additionalProperties).
# ----------------------------------------------------------------------
try:
    import gradio_client.utils as _gcu

    _orig_get_type = _gcu.get_type
    def _safe_get_type(schema):
        if not isinstance(schema, dict):
            return "Any"
        return _orig_get_type(schema)
    _gcu.get_type = _safe_get_type

    _orig_j2p = _gcu._json_schema_to_python_type
    def _safe_j2p(schema, defs=None):
        if not isinstance(schema, dict):
            return "Any"
        return _orig_j2p(schema, defs)
    _gcu._json_schema_to_python_type = _safe_j2p
except Exception:
    pass

# ----------------------------------------------------------------------
# CONFIGURAÇÃO
# ----------------------------------------------------------------------
MODELOS_WHISPER = ["tiny", "base", "small", "medium", "large-v3"]
MODELO_PADRAO = "small"          # bom equilíbrio velocidade x qualidade
OLLAMA_URL = "http://localhost:11434"
IDIOMAS = {"Detectar automaticamente": None, "Português": "pt", "Inglês": "en",
           "Espanhol": "es", "Francês": "fr", "Alemão": "de", "Italiano": "it"}

_modelos_carregados = {}


def carregar_modelo(nome):
    """Carrega o modelo Whisper uma única vez (cache em memória)."""
    if nome not in _modelos_carregados:
        from faster_whisper import WhisperModel
        _modelos_carregados[nome] = WhisperModel(nome, device="auto", compute_type="auto")
    return _modelos_carregados[nome]


# ----------------------------------------------------------------------
# TRANSCRIÇÃO
# ----------------------------------------------------------------------
def transcrever_arquivo(caminho, modelo_nome, idioma_label):
    if not caminho:
        return "", "", None, None
    modelo = carregar_modelo(modelo_nome)
    idioma = IDIOMAS.get(idioma_label)

    segments, info = modelo.transcribe(
        caminho, language=idioma, vad_filter=True, beam_size=5
    )

    linhas_txt, linhas_srt = [], []
    for i, seg in enumerate(segments, start=1):
        texto = seg.text.strip()
        linhas_txt.append(texto)
        linhas_srt.append(
            f"{i}\n{_ts(seg.start)} --> {_ts(seg.end)}\n{texto}\n"
        )

    transcricao = " ".join(linhas_txt).strip()
    srt = "\n".join(linhas_srt)

    txt_path = _salvar(transcricao, ".txt")
    srt_path = _salvar(srt, ".srt")

    detalhes = f"Idioma detectado: {info.language} | Duração: {info.duration:.0f}s"
    return transcricao, detalhes, txt_path, srt_path


def transcrever_url(url, modelo_nome, idioma_label):
    """Baixa o áudio de um link (YouTube, Instagram, TikTok, sites) e transcreve."""
    if not url or not url.strip():
        return "", "Cole um link primeiro.", None, None
    import yt_dlp

    tmpdir = tempfile.mkdtemp()
    saida = os.path.join(tmpdir, "audio.%(ext)s")
    opts = {
        "format": "bestaudio/best",
        "outtmpl": saida,
        "postprocessors": [{"key": "FFmpegExtractAudio",
                            "preferredcodec": "mp3", "preferredquality": "128"}],
        "quiet": True, "noplaylist": True,
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([url.strip()])
    except Exception as e:
        return "", f"Erro ao baixar: {e}", None, None

    arquivos = [os.path.join(tmpdir, f) for f in os.listdir(tmpdir)]
    if not arquivos:
        return "", "Não foi possível extrair o áudio deste link.", None, None
    return transcrever_arquivo(arquivos[0], modelo_nome, idioma_label)


# ----------------------------------------------------------------------
# RESUMO COM OLLAMA (local)
# ----------------------------------------------------------------------
PROMPT_RESUMO = """Você é um assistente especializado em resumir transcrições.
Resuma o texto abaixo em português, no formato:

**Resumo geral** (2-3 frases)
**Pontos principais** (lista)
**Ações/decisões** (se houver, ex.: em reuniões)

Texto:
{texto}"""


def listar_modelos_ollama():
    try:
        import requests
        r = requests.get(f"{OLLAMA_URL}/api/tags", timeout=3)
        nomes = [m["name"] for m in r.json().get("models", [])]
        return nomes or ["(nenhum modelo instalado)"]
    except Exception:
        return ["(Ollama não encontrado — abra o Ollama e clique em Atualizar)"]


def resumir(texto, modelo_ollama):
    if not texto.strip():
        return "Transcreva algo primeiro."
    if modelo_ollama.startswith("("):
        return "Ollama não está disponível. Instale em https://ollama.com e rode: ollama pull llama3.1"
    try:
        import requests
        r = requests.post(
            f"{OLLAMA_URL}/api/generate",
            json={"model": modelo_ollama,
                  "prompt": PROMPT_RESUMO.format(texto=texto[:24000]),
                  "stream": False},
            timeout=600,
        )
        return r.json().get("response", "Sem resposta do Ollama.")
    except Exception as e:
        return f"Erro ao conectar no Ollama: {e}"


def melhor_modelo():
    """Escolhe automaticamente o melhor modelo Ollama instalado."""
    modelos = listar_modelos_ollama()
    if not modelos or modelos[0].startswith("("):
        return None
    for pref in ("llama3.2:3b", "llama3.1", "llama3", "llama3.2", "mistral", "qwen"):
        for m in modelos:
            if m.startswith(pref):
                return m
    return modelos[0]


def auto_resumir(texto, modelo_ollama, ativo):
    """Chamado automaticamente após a transcrição, sem clicar em nada."""
    if not ativo or not texto or not texto.strip():
        return gr.update()
    if not modelo_ollama or str(modelo_ollama).startswith("("):
        modelo_ollama = melhor_modelo()
    if not modelo_ollama:
        return gr.update()
    return resumir(texto, modelo_ollama)


# ----------------------------------------------------------------------
# UTILITÁRIOS
# ----------------------------------------------------------------------
def _ts(segundos):
    td = datetime.timedelta(seconds=segundos)
    total = int(td.total_seconds())
    ms = int((td.total_seconds() - total) * 1000)
    h, resto = divmod(total, 3600)
    m, s = divmod(resto, 60)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _salvar(conteudo, ext):
    f = tempfile.NamedTemporaryFile(mode="w", suffix=ext, delete=False,
                                    encoding="utf-8")
    f.write(conteudo)
    f.close()
    return f.name


# ----------------------------------------------------------------------
# INTERFACE
# ----------------------------------------------------------------------
with gr.Blocks(title="ChatGosipt", theme=gr.themes.Soft()) as app:
    gr.Markdown("# 🎙️ ChatGosipt\nTranscrição local com Whisper + resumos com Ollama. "
                "Funciona offline para arquivos e reuniões.")

    with gr.Row():
        modelo_whisper = gr.Dropdown(MODELOS_WHISPER, value=MODELO_PADRAO,
                                     label="Modelo Whisper")
        idioma = gr.Dropdown(list(IDIOMAS.keys()), value="Detectar automaticamente",
                             label="Idioma")

    with gr.Tabs():
        # --- ARQUIVO / WHATSAPP ---
        with gr.Tab("📁 Arquivo (WhatsApp, áudio, vídeo)"):
            arquivo = gr.File(label="Arraste o arquivo aqui (.opus, .ogg, .mp3, .mp4, .m4a, .wav...)",
                              type="filepath")
            btn_arq = gr.Button("Transcrever arquivo", variant="primary")

        # --- LINK ---
        with gr.Tab("🔗 Link (YouTube, Instagram, TikTok, sites)"):
            url = gr.Textbox(label="Cole o link do vídeo ou áudio",
                             placeholder="https://...")
            btn_url = gr.Button("Transcrever link", variant="primary")
            gr.Markdown("*Links exigem internet. Arquivos e reuniões funcionam offline.*")

        # --- REUNIÃO ---
        with gr.Tab("🎤 Gravar reunião"):
            mic = gr.Audio(sources=["microphone"], type="filepath",
                           label="Grave a reunião (clique para iniciar/parar)")
            btn_mic = gr.Button("Transcrever gravação", variant="primary")

    transcricao = gr.Textbox(label="Transcrição (clique no ícone para copiar)",
                             lines=12, show_copy_button=True)
    detalhes = gr.Markdown()
    with gr.Row():
        arq_txt = gr.File(label="Baixar .txt")
        arq_srt = gr.File(label="Baixar .srt (legendas)")

    gr.Markdown("## 🧠 Resumo com Ollama (local)")
    with gr.Row():
        modelo_ollama = gr.Dropdown(listar_modelos_ollama(),
                                    label="Modelo Ollama", scale=3)
        btn_refresh = gr.Button("🔄 Atualizar", scale=1)
    btn_resumo = gr.Button("Gerar resumo", variant="secondary")
    resumo = gr.Textbox(label="Resumo (clique no ícone para copiar)",
                        lines=10, show_copy_button=True)

    # Eventos
    saidas = [transcricao, detalhes, arq_txt, arq_srt]
    btn_arq.click(transcrever_arquivo, [arquivo, modelo_whisper, idioma], saidas)
    btn_url.click(transcrever_url, [url, modelo_whisper, idioma], saidas)
    btn_mic.click(transcrever_arquivo, [mic, modelo_whisper, idioma], saidas)
    btn_refresh.click(lambda: gr.Dropdown(choices=listar_modelos_ollama()),
                      None, modelo_ollama)
    btn_resumo.click(resumir, [transcricao, modelo_ollama], resumo)

if __name__ == "__main__":
    import sys
    # Use "python app.py --rede" para acessar do iPhone/iPad na mesma rede Wi-Fi
    host = "0.0.0.0" if "--rede" in sys.argv else "127.0.0.1"
    app.launch(server_name=host, server_port=7860, inbrowser=True)
