# -*- coding: utf-8 -*-
"""
API do Transcritor Pro — para o Atalho do iPhone / WhatsApp
============================================================
Recebe um áudio por HTTP e devolve o texto transcrito (+ resumo opcional
com o llama via Ollama). Roda na rede local (mesmo Wi-Fi do iPhone).

Iniciar:
    .venv/bin/python api_whatsapp.py            # escuta em 0.0.0.0:7861

Endpoint:
    POST http://<IP-DO-MAC>:7861/transcrever
        form-data:
            audio        = arquivo de áudio (obrigatório)
            modelo       = tiny|base|small|medium|large-v3   (opcional, padrão: small)
            idioma       = pt|en|...  (opcional; vazio = detectar automático)
            resumir      = 1 para gerar resumo com o llama (opcional)
            modelo_ollama= llama3.2:1b (opcional)
    Resposta JSON: { ok, idioma, duracao, texto, resumo }
"""

import os
import tempfile

import requests
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import JSONResponse, PlainTextResponse
from fastapi.middleware.cors import CORSMiddleware

OLLAMA_URL = "http://localhost:11434"

app = FastAPI(title="ChatGosipt API")

# Libera chamadas da extensão do Chrome e de outras origens locais
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# cache dos modelos Whisper (carrega só na 1ª vez que é usado)
_modelos = {}


def carregar_modelo(nome: str):
    if nome not in _modelos:
        from faster_whisper import WhisperModel
        _modelos[nome] = WhisperModel(nome, device="auto", compute_type="auto")
    return _modelos[nome]


def resumir_com_llama(texto: str, modelo_ollama: str) -> str:
    try:
        prompt = (
            "Resuma a transcrição a seguir em português, em tópicos curtos com os "
            "pontos principais e, se houver, decisões e próximos passos:\n\n" + texto
        )
        r = requests.post(
            f"{OLLAMA_URL}/api/generate",
            json={"model": modelo_ollama, "prompt": prompt, "stream": False},
            timeout=120,
        )
        return r.json().get("response", "").strip()
    except Exception as e:
        return f"(Não foi possível resumir: {e})"


@app.get("/")
def health():
    return PlainTextResponse("ChatGosipt API no ar. Use POST /transcrever")


@app.post("/transcrever")
async def transcrever(
    audio: UploadFile = File(...),
    modelo: str = Form("small"),
    idioma: str = Form(""),
    resumir: str = Form("0"),
    modelo_ollama: str = Form("llama3.2:1b"),
):
    # salva o áudio recebido num arquivo temporário
    sufixo = os.path.splitext(audio.filename or "audio")[1] or ".ogg"
    with tempfile.NamedTemporaryFile(delete=False, suffix=sufixo) as tmp:
        tmp.write(await audio.read())
        caminho = tmp.name

    try:
        mdl = carregar_modelo(modelo)
        lang = idioma.strip() or None
        segments, info = mdl.transcribe(
            caminho, language=lang, vad_filter=True, beam_size=5
        )
        texto = " ".join(seg.text.strip() for seg in segments).strip()

        resumo = ""
        if resumir in ("1", "true", "sim", "on"):
            resumo = resumir_com_llama(texto, modelo_ollama)

        return JSONResponse({
            "ok": True,
            "idioma": info.language,
            "duracao": round(info.duration, 1),
            "texto": texto,
            "resumo": resumo,
        })
    except Exception as e:
        return JSONResponse({"ok": False, "erro": str(e)}, status_code=500)
    finally:
        try:
            os.unlink(caminho)
        except Exception:
            pass


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=7861)
